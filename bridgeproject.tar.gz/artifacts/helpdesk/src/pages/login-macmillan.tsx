import { Link, useLocation } from "wouter";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { customFetch, useLogin } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { BookOpenText, Eye, EyeOff, GraduationCap, Headphones, Loader2, Lock, Mail, PlugZap, UserRoundCheck } from "lucide-react";
import { getDefaultRouteForRole } from "@/lib/default-route";
import { toast } from "@/hooks/use-toast";
import meeLogo from "@/assets/mee-logo.svg";

const loginSchema = z.object({
  email: z.string().email("Introduce un correo electronico valido"),
  password: z.string().min(6, "La contrasena debe tener al menos 6 caracteres"),
  captchaAnswer: z.string().optional(),
  rememberMe: z.boolean(),
});

const supportContactSchema = z.object({
  name: z.string().trim().min(2, "Introduce tu nombre"),
  email: z.string().trim().email("Introduce un correo valido"),
  phone: z.string().trim().max(40).optional(),
  schoolName: z.string().trim().max(160).optional(),
  subject: z.string().trim().min(3, "Indica un asunto breve"),
  message: z.string().trim().min(10, "Cuentanos brevemente que necesitas"),
});

const RECENT_LOGIN_EMAILS_STORAGE_KEY = "helpdesk-recent-login-emails";
const MAX_RECENT_LOGIN_EMAILS = 5;

type LoginFormValues = z.infer<typeof loginSchema>;
type SupportContactFormValues = z.infer<typeof supportContactSchema>;
type CaptchaChallenge = {
  question: string;
  token: string;
};

const featureItems = [
  {
    icon: Headphones,
    title: "Soporte",
    description: "Tickets de consultas,\natencion rapida.",
  },
  {
    icon: BookOpenText,
    title: "Recursos",
    description: "Acceso a guias,\ndocumentacion y mas",
  },
  {
    icon: UserRoundCheck,
    title: "Solicitud de\nasistencia",
    description: "Planificacion y gestion\nde intervenciones",
    glow: true,
  },
  {
    icon: GraduationCap,
    title: "Formacion",
    description: "Capacitacion y\ncontenidos formativos",
  },
  {
    icon: PlugZap,
    title: "API externa",
    description: "Conexion segura con\nnuestros sistemas",
  },
];

function readRecentLoginEmails() {
  try {
    const rawValue = window.localStorage.getItem(RECENT_LOGIN_EMAILS_STORAGE_KEY);
    const parsedValue = rawValue ? JSON.parse(rawValue) : [];
    return Array.isArray(parsedValue)
      ? parsedValue.filter((value): value is string => typeof value === "string" && value.includes("@"))
      : [];
  } catch {
    return [];
  }
}

function writeRecentLoginEmails(email: string) {
  const normalizedEmail = email.trim().toLowerCase();
  if (!normalizedEmail) return readRecentLoginEmails();

  const nextEmails = [
    normalizedEmail,
    ...readRecentLoginEmails().filter((recentEmail) => recentEmail.toLowerCase() !== normalizedEmail),
  ].slice(0, MAX_RECENT_LOGIN_EMAILS);

  window.localStorage.setItem(RECENT_LOGIN_EMAILS_STORAGE_KEY, JSON.stringify(nextEmails));
  return nextEmails;
}

function HeroWordmark() {
  return (
    <div>
      <div className="flex flex-wrap items-end gap-2 leading-none">
        <span className="text-[48px] font-semibold tracking-tight text-white sm:text-[58px] lg:text-[74px]">Macmillan</span>
        <span className="text-[48px] font-bold tracking-tight text-[#ff7a1a] sm:text-[58px] lg:text-[74px]">Bridge</span>
      </div>
      <div className="mt-4 h-1 w-14 rounded-full bg-[#ff7a1a]" />
      <p className="mt-7 text-[24px] leading-tight text-white/95 sm:text-[28px] lg:text-[34px]">
        Plataforma de soporte y servicios
      </p>
    </div>
  );
}

function BackgroundRays() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_76%_34%,rgba(80,170,255,0.95),rgba(42,112,230,0.74)_16%,rgba(15,54,152,0.42)_32%,rgba(7,31,103,0)_55%)]" />
      <div className="absolute inset-y-0 left-[22%] right-0 top-[30%] opacity-80">
        {Array.from({ length: 8 }).map((_, index) => (
          <div
            key={index}
            className="absolute left-0 h-px origin-left rounded-full bg-gradient-to-r from-white/0 via-white/45 to-white/0"
            style={{
              top: `${12 + index * 8}%`,
              width: `${62 + index * 4}%`,
              transform: `rotate(${index * 6 - 18}deg)`,
            }}
          />
        ))}
      </div>
    </div>
  );
}

export default function MacmillanLogin() {
  const [, setLocation] = useLocation();
  const [captchaChallenge, setCaptchaChallenge] = useState<CaptchaChallenge | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [supportDialogOpen, setSupportDialogOpen] = useState(false);
  const [supportSent, setSupportSent] = useState(false);

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "", captchaAnswer: "", rememberMe: true },
  });

  const supportForm = useForm<SupportContactFormValues>({
    resolver: zodResolver(supportContactSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      schoolName: "",
      subject: "",
      message: "",
    },
  });

  const loginMutation = useLogin({
    mutation: {
      onSuccess: (response) => {
        setCaptchaChallenge(null);
        form.setValue("captchaAnswer", "");

        if (form.getValues("rememberMe")) {
          writeRecentLoginEmails(form.getValues("email"));
        } else {
          window.localStorage.removeItem(RECENT_LOGIN_EMAILS_STORAGE_KEY);
        }

        setLocation(response.mustChangePassword ? "/change-password" : getDefaultRouteForRole(response.role));
      },
      onError: (error) => {
        const data = (error as any)?.data;
        if (data?.captchaRequired && data?.captcha?.question && data?.captcha?.token) {
          setCaptchaChallenge(data.captcha);
          form.setValue("captchaAnswer", "");
        }
      },
    },
  });

  const supportMutation = useMutation({
    mutationFn: async (values: SupportContactFormValues) =>
      customFetch<{ message: string }>("/api/auth/support-contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      }),
    onSuccess: (response) => {
      setSupportSent(true);
      toast({
        title: "Solicitud registrada",
        description: response.message,
      });
    },
    onError: (error) => {
      toast({
        title: "No se pudo registrar la solicitud",
        description: error instanceof Error ? error.message : "Intentalo de nuevo en unos minutos.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    const emails = readRecentLoginEmails();
    if (emails[0] && !form.getValues("email")) {
      form.setValue("email", emails[0], { shouldValidate: false });
    }
  }, [form]);

  useEffect(() => {
    const loginEmail = form.getValues("email");
    if (loginEmail && !supportForm.getValues("email")) {
      supportForm.setValue("email", loginEmail, { shouldValidate: false });
    }
  }, [form, supportForm]);

  function onSubmit(data: LoginFormValues) {
    if (captchaChallenge && !data.captchaAnswer?.trim()) {
      form.setError("captchaAnswer", { message: "Resuelve el captcha para continuar" });
      return;
    }

    loginMutation.mutate({
      data: {
        email: data.email,
        password: data.password,
        captchaAnswer: data.captchaAnswer,
        captchaToken: captchaChallenge?.token,
      },
    });
  }

  function getLoginErrorMessage() {
    const rawMessage = loginMutation.error?.message || "";

    if (
      rawMessage.includes("401") ||
      rawMessage.includes("429") ||
      rawMessage.toLowerCase().includes("credenciales")
    ) {
      return "Credenciales no validas";
    }

    if (rawMessage.toLowerCase().includes("failed to fetch")) {
      return "No se pudo conectar con el servidor. Intentalo de nuevo en unos segundos.";
    }

    return "No se pudo iniciar sesion. Revisa tus datos e intentalo de nuevo.";
  }

  function openSupportDialog() {
    setSupportSent(false);
    supportForm.reset({
      name: "",
      email: form.getValues("email") || "",
      phone: "",
      schoolName: "",
      subject: "",
      message: "",
    });
    setSupportDialogOpen(true);
  }

  return (
    <div className="min-h-screen overflow-hidden bg-[linear-gradient(115deg,#041955_0%,#072a82_30%,#0f42b0_64%,#2d7fff_100%)]">
      <div className="relative mx-auto flex min-h-screen max-w-[1600px] flex-col px-4 py-4 lg:px-6 lg:py-5">
        <BackgroundRays />

        <div className="relative grid flex-1 gap-6 lg:grid-cols-[minmax(0,1fr)_430px] lg:items-center lg:gap-10">
          <section className="flex min-h-0 flex-col justify-between py-2 lg:py-4">
            <div className="max-w-[740px]">
              <HeroWordmark />

              <p className="mt-10 max-w-[640px] text-[22px] leading-[1.55] text-white/92 sm:text-[24px] lg:text-[26px]">
                Bridge te conecta con los equipos, servicios y soluciones de Macmillan Education, ofreciendo una experiencia unificada, agil y orientada al valor.
              </p>
            </div>

            <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5 xl:gap-0">
              {featureItems.map(({ icon: Icon, title, description, glow }) => (
                <div
                  key={title}
                  className="flex flex-col items-center rounded-[22px] border border-white/12 bg-white/5 px-3 py-4 text-center backdrop-blur-[1px] xl:rounded-none xl:border-0 xl:bg-transparent xl:px-4 xl:py-0 xl:last:border-r-0"
                >
                  <div
                    className={[
                      "mb-4 flex h-16 w-16 items-center justify-center rounded-full border text-white",
                      glow
                        ? "border-sky-300/70 bg-sky-400/12 shadow-[0_0_0_4px_rgba(59,130,246,0.18),0_0_30px_rgba(56,189,248,0.18)]"
                        : "border-white/30 bg-white/7",
                    ].join(" ")}
                  >
                    <Icon className="h-7 w-7" strokeWidth={1.8} />
                  </div>
                  <h3 className="whitespace-pre-line text-[18px] font-semibold leading-[1.12] text-white lg:text-[20px]">
                    {title}
                  </h3>
                  <p className="mt-2 whitespace-pre-line text-[13px] leading-[1.45] text-white/78 lg:text-[14px]">
                    {description}
                  </p>
                </div>
              ))}
            </div>
          </section>

          <aside className="flex items-center justify-center">
            <div className="w-full rounded-[28px] border border-white/75 bg-white/98 p-7 shadow-[0_28px_80px_-36px_rgba(4,10,31,0.72)] lg:p-8">
              <div className="text-center">
                <h2 className="text-[42px] font-bold tracking-tight text-[#082c63] lg:text-[56px]">Bienvenido</h2>
                <p className="mt-2 text-[16px] text-slate-600 lg:text-[18px]">Inicia sesion para continuar</p>
              </div>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="mt-8 space-y-5">
                  {loginMutation.isError && (
                    <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
                      {getLoginErrorMessage()}
                    </div>
                  )}

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-[15px] font-semibold text-[#082c63]">Correo electronico</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Mail className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
                            <Input
                              placeholder="usuario@macmillan.com"
                              {...field}
                              className="h-12 rounded-xl border-slate-200 pl-12 text-[16px] text-slate-700 placeholder:text-slate-400"
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-[15px] font-semibold text-[#082c63]">Contrasena</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Lock className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
                            <Input
                              type={showPassword ? "text" : "password"}
                              placeholder="••••••••••"
                              {...field}
                              className="h-12 rounded-xl border-slate-200 pl-12 pr-12 text-[16px] text-slate-700 placeholder:text-slate-400"
                            />
                            <button
                              type="button"
                              className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 transition hover:text-slate-600"
                              onClick={() => setShowPassword((current) => !current)}
                              aria-label={showPassword ? "Ocultar contrasena" : "Mostrar contrasena"}
                            >
                              {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {captchaChallenge && (
                    <FormField
                      control={form.control}
                      name="captchaAnswer"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-[15px] font-semibold text-[#082c63]">Verificacion de seguridad</FormLabel>
                          <div className="rounded-xl border border-amber-200 bg-amber-50 p-3">
                            <p className="mb-2 text-sm font-medium text-amber-900">
                              Resuelve para continuar: <span className="font-bold">{captchaChallenge.question}</span>
                            </p>
                            <FormControl>
                              <Input inputMode="numeric" placeholder="Resultado" {...field} className="h-11 rounded-lg bg-white text-[15px]" />
                            </FormControl>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <div className="flex flex-col gap-3 text-sm text-slate-600 sm:flex-row sm:items-center sm:justify-between">
                    <FormField
                      control={form.control}
                      name="rememberMe"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center gap-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={(checked) => field.onChange(Boolean(checked))}
                              className="h-5 w-5 rounded-md border-slate-300"
                            />
                          </FormControl>
                          <FormLabel className="cursor-pointer text-[14px] font-medium text-slate-700">Recordarme</FormLabel>
                        </FormItem>
                      )}
                    />

                    <Link href="/forgot-password">
                      <span className="cursor-pointer text-[14px] font-medium text-[#2563eb] hover:underline">
                        Olvidaste tu contrasena?
                      </span>
                    </Link>
                  </div>

                  <Button
                    type="submit"
                    className="h-12 w-full rounded-xl bg-[#0a2d60] text-[18px] font-semibold text-white hover:bg-[#11356c]"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Iniciando sesion
                      </>
                    ) : (
                      "Iniciar sesion"
                    )}
                  </Button>

                  <div className="flex items-center gap-3 pt-1">
                    <div className="h-px flex-1 bg-slate-200" />
                    <span className="text-xs text-slate-400">o</span>
                    <div className="h-px flex-1 bg-slate-200" />
                  </div>

                  <p className="pt-2 text-center text-[14px] leading-6 text-slate-700">
                    Necesitas ayuda? Contacta con el{" "}
                    <button
                      type="button"
                      className="font-medium text-[#2563eb] hover:underline"
                      onClick={openSupportDialog}
                    >
                      equipo de soporte
                    </button>
                  </p>
                </form>
              </Form>
            </div>
          </aside>
        </div>

        <footer className="relative mt-4 rounded-[18px] bg-[#07245d]/92 px-5 py-4 text-white backdrop-blur-sm">
          <div className="flex flex-col items-center justify-between gap-3 text-center text-[14px] lg:flex-row lg:text-left lg:text-[15px]">
            <div className="flex items-center gap-3">
              <img src={meeLogo} alt="Macmillan Education" className="h-7 w-auto brightness-0 invert" />
              <span className="font-medium">macmillan education</span>
            </div>
            <span className="font-medium">bridge.macmillan.es</span>
            <span>&copy; 2024 Macmillan Education. Todos los derechos reservados.</span>
          </div>
        </footer>

        <Dialog
          open={supportDialogOpen}
          onOpenChange={(open) => {
            setSupportDialogOpen(open);
            if (!open) {
              setSupportSent(false);
            }
          }}
        >
          <DialogContent className="max-w-xl rounded-2xl">
            <DialogHeader>
              <DialogTitle>Contactar con soporte</DialogTitle>
              <DialogDescription>
                Rellena este formulario y registraremos una consulta para que el equipo de soporte la vea directamente en Bridge.
              </DialogDescription>
            </DialogHeader>

            {supportSent ? (
              <div className="space-y-4">
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-5 text-sm text-emerald-800">
                  Tu solicitud se ha registrado correctamente en el sistema de soporte. El equipo la revisara lo antes posible.
                </div>
                <DialogFooter>
                  <Button type="button" onClick={() => setSupportDialogOpen(false)}>
                    Cerrar
                  </Button>
                </DialogFooter>
              </div>
            ) : (
              <Form {...supportForm}>
                <form
                  onSubmit={supportForm.handleSubmit((values) => supportMutation.mutate(values))}
                  className="space-y-4"
                >
                  <div className="grid gap-4 md:grid-cols-2">
                    <FormField
                      control={supportForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nombre</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Tu nombre" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={supportForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Correo electronico</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="tu@colegio.es" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <FormField
                      control={supportForm.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Telefono</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Opcional" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={supportForm.control}
                      name="schoolName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Colegio o centro</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Opcional" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={supportForm.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Asunto</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Necesito ayuda para acceder a la plataforma" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={supportForm.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mensaje</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Describe brevemente lo que necesitas y, si puedes, indica el problema o la consulta."
                            className="min-h-[140px]"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setSupportDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit" disabled={supportMutation.isPending}>
                      {supportMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Enviando...
                        </>
                      ) : (
                        "Registrar solicitud"
                      )}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
