import { Badge } from "@/components/ui/badge";
import { TicketStatus, TicketPriority } from "@workspace/api-client-react";
import { getRoleLabel } from "@/lib/role-labels";

export function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, { bg: string, text: string, label: string }> = {
    [TicketStatus.nuevo]: { bg: "bg-blue-100 dark:bg-blue-900/30", text: "text-blue-700 dark:text-blue-400", label: "Nuevo" },
    [TicketStatus.pendiente]: { bg: "bg-yellow-100 dark:bg-yellow-900/30", text: "text-yellow-800 dark:text-yellow-400", label: "Pendiente" },
    [TicketStatus.en_revision]: { bg: "bg-orange-100 dark:bg-orange-900/30", text: "text-orange-800 dark:text-orange-400", label: "En Revision" },
    [TicketStatus.en_proceso]: { bg: "bg-purple-100 dark:bg-purple-900/30", text: "text-purple-700 dark:text-purple-400", label: "En Proceso" },
    [TicketStatus.esperando_cliente]: { bg: "bg-amber-100 dark:bg-amber-900/30", text: "text-amber-800 dark:text-amber-400", label: "Esperando Cliente" },
    [TicketStatus.resuelto]: { bg: "bg-emerald-100 dark:bg-emerald-900/30", text: "text-emerald-700 dark:text-emerald-400", label: "Resuelto" },
    [TicketStatus.cerrado]: { bg: "bg-slate-100 dark:bg-slate-800", text: "text-slate-600 dark:text-slate-400", label: "Cerrado" },
  };

  const v = variants[status as TicketStatus] || { bg: "bg-slate-100", text: "text-slate-700", label: status };

  return (
    <Badge variant="outline" className={`${v.bg} ${v.text} border-transparent font-medium shadow-none`}>
      {v.label}
    </Badge>
  );
}

export function PriorityBadge({ priority }: { priority: string }) {
  const variants: Record<string, { bg: string, text: string, label: string }> = {
    [TicketPriority.baja]: { bg: "bg-slate-100 dark:bg-slate-800", text: "text-slate-600 dark:text-slate-400", label: "Baja" },
    [TicketPriority.media]: { bg: "bg-blue-100 dark:bg-blue-900/30", text: "text-blue-700 dark:text-blue-400", label: "Media" },
    [TicketPriority.alta]: { bg: "bg-orange-100 dark:bg-orange-900/30", text: "text-orange-800 dark:text-orange-400", label: "Alta" },
    [TicketPriority.urgente]: { bg: "bg-red-100 dark:bg-red-900/30", text: "text-red-700 dark:text-red-400", label: "Urgente" },
  };

  const v = variants[priority as TicketPriority] || { bg: "bg-slate-100", text: "text-slate-700", label: priority };

  return (
    <Badge variant="outline" className={`${v.bg} ${v.text} border-transparent font-medium shadow-none`}>
      {v.label}
    </Badge>
  );
}

export function RoleBadge({ role }: { role: string }) {
  const variants: Record<string, { bg: string, text: string, label: string }> = {
    superadmin: { bg: "bg-indigo-100 dark:bg-indigo-900/30", text: "text-indigo-700 dark:text-indigo-400", label: getRoleLabel("superadmin") },
    admin_cliente: { bg: "bg-violet-100 dark:bg-violet-900/30", text: "text-violet-700 dark:text-violet-400", label: getRoleLabel("admin_cliente") },
    manager: { bg: "bg-cyan-100 dark:bg-cyan-900/30", text: "text-cyan-700 dark:text-cyan-400", label: getRoleLabel("manager") },
    tecnico: { bg: "bg-teal-100 dark:bg-teal-900/30", text: "text-teal-700 dark:text-teal-400", label: getRoleLabel("tecnico") },
    usuario_cliente: { bg: "bg-sky-100 dark:bg-sky-900/30", text: "text-sky-700 dark:text-sky-400", label: getRoleLabel("usuario_cliente") },
    visor_cliente: { bg: "bg-slate-100 dark:bg-slate-800", text: "text-slate-600 dark:text-slate-400", label: getRoleLabel("visor_cliente") },
  };

  const v = variants[role] || { bg: "bg-slate-100", text: "text-slate-700", label: getRoleLabel(role) };

  return (
    <Badge variant="outline" className={`${v.bg} ${v.text} border-transparent font-medium shadow-none`}>
      {v.label}
    </Badge>
  );
}

export function AssistanceStatusBadge({ status }: { status: string }) {
  const variants: Record<string, { bg: string; text: string; label: string }> = {
    pendiente: { bg: "bg-amber-100", text: "text-amber-800", label: "Pendiente" },
    aceptada: { bg: "bg-sky-100", text: "text-sky-800", label: "Aceptada" },
    programada: { bg: "bg-indigo-100", text: "text-indigo-700", label: "Programada" },
    en_curso: { bg: "bg-violet-100", text: "text-violet-700", label: "En curso" },
    completada: { bg: "bg-emerald-100", text: "text-emerald-700", label: "Completada" },
    cancelada: { bg: "bg-slate-100", text: "text-slate-700", label: "Cancelada" },
    rechazada: { bg: "bg-rose-100", text: "text-rose-700", label: "Rechazada" },
  };

  const v = variants[status] || { bg: "bg-slate-100", text: "text-slate-700", label: status };

  return (
    <Badge variant="outline" className={`${v.bg} ${v.text} border-transparent font-medium shadow-none`}>
      {v.label}
    </Badge>
  );
}
